function validateForm() {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var phone = document.getElementById('phone').value;
    var location = document.getElementById('location').value;

    // Basic validation
    if (name.trim() == '' || email.trim() == '' || phone.trim() == '' || location.trim() == '') {
        alert('Please fill in all fields.');
        return false;
    }
    
    // Additional validation logic can be added here

    // Show pop-up
    var popup = document.getElementById('popup');
    popup.style.display = 'flex';

    return true; // Form submission allowed if all validations pass
}

function closePopup() {
    var popup = document.getElementById('popup');
    popup.style.display = 'none';
}
